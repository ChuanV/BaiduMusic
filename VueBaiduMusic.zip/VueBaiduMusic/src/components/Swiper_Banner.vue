<template lang="html">
  <div class="banner">
    <swiper :options="swiperOption">
      <swiper-slide>
        <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1567517842106&di=bf2cb4a2dc1f852af0742bacce40f456&imgtype=0&src=http%3A%2F%2Fhbimg.b0.upaiyun.com%2F7bca4cf4257d05a5007be3ac75001157b4c955ef1580c-HiBdRx_fw658" alt="">
      </swiper-slide>
      <swiper-slide>
        <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1567517842106&di=bf2cb4a2dc1f852af0742bacce40f456&imgtype=0&src=http%3A%2F%2Fhbimg.b0.upaiyun.com%2F7bca4cf4257d05a5007be3ac75001157b4c955ef1580c-HiBdRx_fw658" alt="">
      </swiper-slide>
      <swiper-slide>
        <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1567517842106&di=bf2cb4a2dc1f852af0742bacce40f456&imgtype=0&src=http%3A%2F%2Fhbimg.b0.upaiyun.com%2F7bca4cf4257d05a5007be3ac75001157b4c955ef1580c-HiBdRx_fw658" alt="">
      </swiper-slide>
      <div class="swiper-pagination"  slot="pagination"></div>
    </swiper>
  </div>
</template>

<script>

import 'swiper/dist/css/swiper.css'
import { swiper, swiperSlide } from 'vue-awesome-swiper'

export default {
  data(){
    return{
      swiperOption:{
        pagination: {
          el: '.swiper-pagination',
        },
        autoplay:true
      }
    }
  },
  components: {
    swiper,
    swiperSlide
  }
}
</script>

<style scoped>

.banner{
  padding: 10px;
}

</style>

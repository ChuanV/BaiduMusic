<template>
  <div class="listcate">
     <ListCateList v-for="(item,index) in musicTypeJSON" :musicType="item" :key="index"/>
  </div>
</template>

<script>
import ListCateList from '@/components/ListCate_List'
export default {
  name:"listcate",
  data(){
    return{
      musicTypeJSON:[1,2,11,21,22,23,24,25]
    }
  },
  components:{
    ListCateList
  }
}
</script>

<style>

</style>
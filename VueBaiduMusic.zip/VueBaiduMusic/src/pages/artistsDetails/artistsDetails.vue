<template>
  <div class="artistdetails">
      <Title :name="this.$route.params.name" :avatar="this.$route.params.avatar" />
      <List :ting_uid="this.$route.params.ting_uid" />
  </div>
</template>

<script>
import List from "../../components/details/list"
import Title from "../../components/details/title"
export default {
    name:"artistsdetails",
    data(){
        return{

        }
    },
    components:{
        List,
        Title
    }

}
</script>

<style>

</style>
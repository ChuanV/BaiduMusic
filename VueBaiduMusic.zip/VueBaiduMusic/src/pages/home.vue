<template>
  <div>
    <TodayRecommend title="今日榜单" type="1" />
    <NewsMusic />
    <SwiperBanner />
    <MusicListNav />
    <keep-alive>
      <router-view />
    </keep-alive>
    <TodayRecommend title="热门歌单" type="24" />
  </div>
</template>

<script>
  import TodayRecommend from '../components/TodayRecommend'
  import NewsMusic from '../components/News_Music'
  import SwiperBanner from '../components/Swiper_Banner.vue'
  import MusicList from '../components/Music_List.vue'
  import MusicListNav from './musiclist/music_listnav'
  export default{
    name:'home',
    components:{
       TodayRecommend,
       NewsMusic,
       SwiperBanner,
       MusicListNav,
       MusicList
    }
  }
</script>

<style>
</style>

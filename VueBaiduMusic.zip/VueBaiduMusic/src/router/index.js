import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/pages/home'
import Index from '@/pages/index'
import HotList from '@/pages/musiclist/hot_list'
import KingList from '@/pages/musiclist/king_list'
import NewsList from '@/pages/musiclist/news_list'
import MusicPlay from '@/pages/musicplay'
import MoreList from '@/pages/morelist'
import Artists from '@/pages/artists'
import Ucenter from '@/pages/ucenter'
import ListCate from '@/pages/listcate'
import Search from '@/pages/search'
import ListCateDetails from '@/pages/listcateDetails/listcateDetails'
import ArtistsDetails from '@/pages/artistsDetails/artistsDetails'

Vue.use(Router)

export default new Router({
  base: '/dist/',  
  routes: [
    {
      path:'musicplay',
      name:"MusicPlay",
      component:MusicPlay
    },
    {
      path: '/',
      name: 'Index',
      redirect:'/home',
      component:Index,
      children:[
        {
          path:'/home',
          component:Home,
          redirect:'/home/hot',
          children:[
            {
              path:'hot',
              component:HotList
            },
            {
              path:'king',
              component:KingList
            },
            {
              path:'news',
              component:NewsList
              
            }
          ]
        },
        {
          path:"morelist",
          name:"MoreList",
          component:MoreList
        },
        {
          path:"artists",
          component:Artists
        },
        {
          path:"ucenter",
          component:Ucenter
        },
        {
          path:"search",
          component:Search
        },
        {
          path:"listcate",
          component:ListCate
        },{
          path:"listcatedetails",
          name:"ListCateDetails",
          component:ListCateDetails
        },
        {
          path:"artistsdetails",
          name:"ArtistsDetails",
          component:ArtistsDetails
        }
      ]

    }
  ]
})
